package com.example.whatsapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class PhoneLoginActivity extends AppCompatActivity {

    private Button sendVerificationCodeButton,VerifyButton;
    private EditText inputPhoneNumber,inputVerificationCode;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks callbacks;
    private FirebaseAuth mAuth;
    private  String mVerificationId;
    private ProgressDialog loadingBar;

    private PhoneAuthProvider.ForceResendingToken mResendToken;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_login);

        InitilizeFeilds();
        mAuth=FirebaseAuth.getInstance();
    }

    private void InitilizeFeilds() {
      sendVerificationCodeButton=(Button) findViewById(R.id.send_verification_code_button);
      VerifyButton=(Button)findViewById(R.id.verify_button);

      inputPhoneNumber=(EditText) findViewById(R.id.phone_number_input);
      inputVerificationCode=(EditText)findViewById(R.id.verification_code_input);

      loadingBar=new ProgressDialog(this);
      sendVerificationCodeButton.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              String phoneNumber=inputPhoneNumber.getText().toString();
              if(TextUtils.isEmpty(phoneNumber))
              {
                  Toast.makeText(PhoneLoginActivity.this, "Phone Number is Required...", Toast.LENGTH_SHORT).show();
              }
              else
              {
                  loadingBar.setTitle("Phone Verification");
                  loadingBar.setMessage("please wait,while we verifying your phone number...");
                  loadingBar.setCanceledOnTouchOutside(false);
                  loadingBar.show();

                  PhoneAuthProvider.getInstance().verifyPhoneNumber(
                          "+91" + phoneNumber,
                          60,
                          TimeUnit.SECONDS,
                          PhoneLoginActivity.this,
                          new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                              @Override
                              public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                                  signInWithPhoneAuthCredential(phoneAuthCredential);
                              }

                              @Override
                              public void onVerificationFailed(@NonNull FirebaseException e) {
                                  loadingBar.dismiss();
                                  Toast.makeText(PhoneLoginActivity.this, "Invalied Please Enter Correct Phone Number for Your Country Code", Toast.LENGTH_SHORT).show();
                                  sendVerificationCodeButton.setVisibility(View.VISIBLE);
                                  inputPhoneNumber.setVisibility(View.VISIBLE);

                                  VerifyButton.setVisibility(View.INVISIBLE);
                                  inputVerificationCode .setVisibility(View.INVISIBLE);
                              }
                              @Override
                              public void onCodeSent(@NonNull String verificationId,
                                                     @NonNull PhoneAuthProvider.ForceResendingToken token) {
                                  loadingBar.dismiss();
                                  Toast.makeText(PhoneLoginActivity.this, "Code Sent Succesfully On Your Registerd Phone Number,Plese Check Your Sms And Enter Code", Toast.LENGTH_SHORT).show();


                                  sendVerificationCodeButton.setVisibility(View.INVISIBLE);
                                  inputPhoneNumber.setVisibility(View.INVISIBLE);

                                  VerifyButton.setVisibility(View.VISIBLE);
                                  inputVerificationCode .setVisibility(View.VISIBLE);

                                  mVerificationId = verificationId;
                                  mResendToken = token;
                              }
                          }
                  );


              }

          }
      });

      VerifyButton.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              sendVerificationCodeButton.setVisibility(View.INVISIBLE);
              inputPhoneNumber.setVisibility(View.INVISIBLE);

              String verificationCode= inputVerificationCode.getText().toString();
              if(TextUtils.isEmpty(verificationCode))
              {
                  Toast.makeText(PhoneLoginActivity.this, "Please write Verification code first...", Toast.LENGTH_SHORT).show();
              }
             else {

                  loadingBar.setTitle("Code Verification");
                  loadingBar.setMessage("please wait,while we verifying your verification code...");
                  loadingBar.setCanceledOnTouchOutside(false);
                  loadingBar.show();

                  PhoneAuthCredential credential = PhoneAuthProvider.getCredential(mVerificationId, verificationCode);
                  signInWithPhoneAuthCredential(credential);
              }

          }
      });

    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful())
                        {
                          loadingBar.dismiss();
                            Toast.makeText(PhoneLoginActivity.this, "Congratulation,you're logged in successfully...", Toast.LENGTH_SHORT).show();
                            SendUserToMainActivity();
                        }else
                        {
                            String message=task.getException().toString();
                            Toast.makeText(PhoneLoginActivity.this, "Error"+message, Toast.LENGTH_SHORT).show();
                        }
                    }
                });

    }
    private void SendUserToMainActivity() {
        Intent MainIntent=new Intent(PhoneLoginActivity.this,MainActivity.class);
        MainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(MainIntent);
        finish();
    }

}