package com.example.whatsapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity {

    private String reciverUserID,current_state,senderUserID;
    private CircleImageView userProfileImage;
    private TextView userProfileName,userProfileStatus;
    private Button sendMessageRequestButton,cancelMessageRequestButton;
    private DatabaseReference UserRef;
    private DatabaseReference ChatRequestRef,NotificationRef;
    private DatabaseReference ContactsRef;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        UserRef= FirebaseDatabase.getInstance().getReference().child("Users");
        ChatRequestRef=FirebaseDatabase.getInstance().getReference().child("Chat Requests");
        ContactsRef=FirebaseDatabase.getInstance().getReference().child("Contacts");
        NotificationRef=FirebaseDatabase.getInstance().getReference().child("Notifications");
        mAuth=FirebaseAuth.getInstance();

        reciverUserID=getIntent().getExtras().get("visit_user-id").toString();
        senderUserID=mAuth.getCurrentUser().getUid();

        userProfileImage=(CircleImageView) findViewById(R.id.visit_profile_image);
        userProfileName=(TextView) findViewById(R.id.visit_user_name);
        userProfileStatus=(TextView) findViewById(R.id.visit_user_profile_status);
        sendMessageRequestButton=(Button) findViewById(R.id.send_massge_request_button);
        cancelMessageRequestButton=(Button) findViewById(R.id.cancel_massge_request_button);

        current_state="new";

        RetriveUserInfo();
    }

    private void RetriveUserInfo() {
        UserRef.child(reciverUserID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if((snapshot.exists()) && (snapshot.hasChild("image")))
                {
                    //having profile pic set
                    String userImage=snapshot.child("image").getValue().toString();
                    String userName=snapshot.child("name").getValue().toString();
                    String userStatus=snapshot.child("status").getValue().toString();

                    Picasso.get().load(userImage).into(userProfileImage);
                    userProfileName.setText(userName);
                    userProfileStatus.setText(userStatus);
                    ManageChatRequests();

                }else
                {
                  //not having profile pic
                    String userName=snapshot.child("name").getValue().toString();
                    String userStatus=snapshot.child("status").getValue().toString();

                    userProfileName.setText(userName);
                    userProfileStatus.setText(userStatus);
                    ManageChatRequests();

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void ManageChatRequests() {
        ChatRequestRef.child(senderUserID)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.hasChild(reciverUserID))
                        {
                            String request_type=snapshot.child(reciverUserID).child("request_type").getValue().toString();
                            if(request_type.equals("sent"))
                            {
                                current_state="request_sent";
                                sendMessageRequestButton.setText("Cancel Chat Request");
                            }
                            else if(request_type.equals("received"))
                            {
                              current_state="request_received";
                              sendMessageRequestButton.setText("Accept Chat Request");
                              cancelMessageRequestButton.setVisibility(View.VISIBLE);
                              cancelMessageRequestButton.setEnabled(true);
                              cancelMessageRequestButton.setOnClickListener(new View.OnClickListener() {
                                  @Override
                                  public void onClick(View view) {
                                      CancelChatRequest();
                                  }
                              });
                            }
                        }
                        else {
                            ContactsRef.child(senderUserID).addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    if(snapshot.hasChild(reciverUserID))
                                    {
                                        current_state="friends";
                                        sendMessageRequestButton.setText("Remove This Contact");

                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
        if(!senderUserID .equals(reciverUserID))
        {
            sendMessageRequestButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sendMessageRequestButton.setEnabled(false);
                    if(current_state.equals("new"))
                    {
                        SendChatRequest();
                    }
                    if(current_state.equals("request_sent"))
                    {
                        CancelChatRequest();
                    }
                    if(current_state.equals("request_received"))
                    {
                        AcceptChatRequest();
                    }
                    if(current_state.equals("friends"))
                    {
                      removeSpecificContact();
                    }
                }
            });
        }
        else
        {
            sendMessageRequestButton.setVisibility(View.INVISIBLE);
        }
    }



    private void AcceptChatRequest() {
        ContactsRef.child(senderUserID).child(reciverUserID).child("Contacts").setValue("Saved")
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {
                            ContactsRef.child(reciverUserID).child(senderUserID).child("Contacts").setValue("Saved")
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful())
                                            {
                                                 ChatRequestRef.child(senderUserID).child(reciverUserID).removeValue()
                                                         .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                             @Override
                                                             public void onComplete(@NonNull Task<Void> task) {
                                                                 if(task.isSuccessful())
                                                                 {
                                                                     ChatRequestRef.child(reciverUserID).child(senderUserID).removeValue()
                                                                             .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                                 @Override
                                                                                 public void onComplete(@NonNull Task<Void> task) {
                                                                                     if(task.isSuccessful())
                                                                                     {
                                                                                                sendMessageRequestButton.setEnabled(true);
                                                                                                current_state="friends";
                                                                                                sendMessageRequestButton.setText("Remove this Contact");

                                                                                                cancelMessageRequestButton.setVisibility(View.INVISIBLE);
                                                                                                cancelMessageRequestButton.setEnabled(false);

                                                                                     }
                                                                                 }
                                                                             });
                                                                 }
                                                             }
                                                         });
                                            }
                                        }
                                    });
                        }
                    }
                });
    }


    private void SendChatRequest() {
        ChatRequestRef.child(senderUserID).child(reciverUserID)
                .child("request_type").setValue("sent")
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {
                            ChatRequestRef.child(reciverUserID).child(senderUserID).child("request_type").setValue("received")
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful())
                                            {
                                                HashMap<String,String>chatnotficationMap=new HashMap<>();
                                                chatnotficationMap.put("from",senderUserID);
                                                chatnotficationMap.put("type","request");
                                                NotificationRef.child(reciverUserID).push()
                                                                .setValue(chatnotficationMap)
                                                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                            @Override
                                                                            public void onComplete(@NonNull Task<Void> task) {

                                                                                if(task.isSuccessful())
                                                                                {
                                                                                    sendMessageRequestButton.setEnabled(true);
                                                                                    current_state="request_sent";
                                                                                    sendMessageRequestButton.setText("Cancel Chat Request");
                                                                                }
                                                                            }
                                                                        });


                                            }
                                        }
                                    });
                        }
                    }
                });
    }

    private void CancelChatRequest() {
        ChatRequestRef.child(senderUserID).child(reciverUserID)
                .removeValue()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {
                            ChatRequestRef.child(reciverUserID).child(senderUserID)
                                    .removeValue()
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful())
                                            {
                                                    sendMessageRequestButton.setEnabled(true);
                                                    current_state="new";
                                                    sendMessageRequestButton.setText("Send Message Request");

                                                    cancelMessageRequestButton.setVisibility(View.INVISIBLE);
                                                    cancelMessageRequestButton.setEnabled(false);
                                            }
                                        }
                                    });
                        }
                    }
                });
    }

    private void removeSpecificContact() {
        ContactsRef.child(senderUserID).child(reciverUserID)
                .removeValue()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {
                            ChatRequestRef.child(reciverUserID).child(senderUserID)
                                    .removeValue()
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful())
                                            {
                                                sendMessageRequestButton.setEnabled(true);
                                                current_state="new";
                                                sendMessageRequestButton.setText("Send Message Request");

                                                cancelMessageRequestButton.setVisibility(View.INVISIBLE);
                                                cancelMessageRequestButton.setEnabled(false);
                                            }
                                        }
                                    });
                        }
                    }
                });
    }



}