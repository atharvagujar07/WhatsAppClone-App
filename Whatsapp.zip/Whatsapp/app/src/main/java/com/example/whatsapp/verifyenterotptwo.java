package com.example.whatsapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.annotation.NonNull;
import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class verifyenterotptwo extends AppCompatActivity {
    private EditText inputnumber1,inputnumber2,inputnumber3, inputnumber4,inputnumber5, inputnumber6;
    private Button verifyOtpButton;
    private String getoptbackend;
    private ProgressBar progressBar;
    private  PhoneAuthProvider.ForceResendingToken resendingToken;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verifyenterotptwo);

        inputnumber1=(EditText)  findViewById(R.id.inputotp1);
        inputnumber2=(EditText)  findViewById(R.id.inputotp2);
        inputnumber3=(EditText)  findViewById(R.id.inputotp3);
        inputnumber4=(EditText)  findViewById(R.id.inputotp4);
        inputnumber5=(EditText)  findViewById(R.id.inputotp5);
        inputnumber6=(EditText)  findViewById(R.id.inputotp6);

        verifyOtpButton=(Button) findViewById(R.id.button_verify_otp_input) ;

        progressBar = (ProgressBar) findViewById(R.id.progressbar_sending_otp);

        TextView textView=findViewById(R.id.textmobilenumber);
        textView.setText(String.format(
                "+91 %s",getIntent().getStringExtra("mobile")
        ));

        getoptbackend=getIntent().getStringExtra("backendotp");

        verifyOtpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!inputnumber1.getText().toString().trim().isEmpty() && !inputnumber2.getText().toString().trim().isEmpty() && !inputnumber3.getText().toString().trim().isEmpty() && !inputnumber4.getText().toString().trim().isEmpty() && !inputnumber5.getText().toString().trim().isEmpty() && !inputnumber6.getText().toString().trim().isEmpty())
                {
                    String entercodeotp= inputnumber1.getText().toString() +
                            inputnumber2.getText().toString() +
                            inputnumber3.getText().toString() +
                            inputnumber4.getText().toString() +
                            inputnumber5.getText().toString() +
                            inputnumber6.getText().toString() ;
                    if(getoptbackend!=null){
                        progressBar.setVisibility(View.VISIBLE);
                        verifyOtpButton.setVisibility(View.INVISIBLE);

                        PhoneAuthCredential phoneAuthCredential= PhoneAuthProvider.getCredential(
                                getoptbackend,entercodeotp
                        );
                        FirebaseAuth.getInstance().signInWithCredential(phoneAuthCredential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                progressBar.setVisibility(View.GONE);
                                verifyOtpButton.setVisibility(View.VISIBLE);

                                if(task.isSuccessful()){
                                    Intent intent =new Intent(getApplicationContext(),MainActivity.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    startActivity(intent);
                                }
                                else
                                {
                                    Toast.makeText(verifyenterotptwo.this, "Enter The Correct Otp", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }) ;


                    }else
                    {
                        Toast.makeText(verifyenterotptwo.this, "Please Check Your Internet Connection", Toast.LENGTH_SHORT).show();
                    }
                }
                else
                {
                    Toast.makeText(verifyenterotptwo.this, "Please enter correct otp...", Toast.LENGTH_SHORT).show();
                }

            }
        });

        numberOtpMove();

        //resend Button

        TextView resendotp= findViewById(R.id.textresendotp);
        resendotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth mAuth=FirebaseAuth.getInstance();
                String entermobailnumber=getIntent().getStringExtra("mobile");
                PhoneAuthOptions.Builder builder=
                        PhoneAuthOptions.newBuilder(mAuth).
                                setPhoneNumber("+91"+entermobailnumber)
                                .setTimeout(60L,TimeUnit.SECONDS)
                                .setActivity(verifyenterotptwo.this)
                                .setCallbacks(       new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                                    @Override
                                    public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                                        signIn(phoneAuthCredential);
                                    }

                                    @Override
                                    public void onVerificationFailed(@NonNull FirebaseException e) {
                                        progressBar.setVisibility(View.GONE);
                                        verifyOtpButton.setVisibility(View.VISIBLE);
                                        Toast.makeText(verifyenterotptwo.this, "Error Please Check Your Phone Number", Toast.LENGTH_SHORT).show();
                                    }

                                    @Override
                                    public void onCodeSent(@NonNull String backendotp, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                        progressBar.setVisibility(View.GONE);
                                        verifyOtpButton.setVisibility(View.VISIBLE);
                                        resendingToken = forceResendingToken;
                                        String verificationcode = backendotp;
                                        Toast.makeText(verifyenterotptwo.this, "Otp Send Succesfully...!", Toast.LENGTH_SHORT).show();


                                    }
                                });
                PhoneAuthProvider.verifyPhoneNumber(builder.setForceResendingToken(resendingToken).build());


            }
        });
    }

    private void signIn(PhoneAuthCredential phoneAuthCredential) {
    }

    private void numberOtpMove() {

        inputnumber1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (!charSequence.toString().trim().isEmpty()){
                    inputnumber2.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        inputnumber2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (!charSequence.toString().trim().isEmpty()){
                    inputnumber3.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        inputnumber3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (!charSequence.toString().trim().isEmpty()){
                    inputnumber4.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        inputnumber4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (!charSequence.toString().trim().isEmpty()){
                    inputnumber5.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        inputnumber5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (!charSequence.toString().trim().isEmpty()){
                    inputnumber6.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


    }

}