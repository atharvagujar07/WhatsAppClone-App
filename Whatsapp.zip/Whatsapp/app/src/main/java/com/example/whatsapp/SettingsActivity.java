package com.example.whatsapp;

import androidx.annotation.NonNull;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.whatsapp.databinding.ActivityMainBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import java.util.HashMap;
import de.hdodenhof.circleimageview.CircleImageView;

public class SettingsActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private Button UpdateAccountSettings,uploadButton;
    private EditText username,userstatus;
    private CircleImageView userProfileImage;
    private String currentUserID;
    private FirebaseAuth mAuth;
    private DatabaseReference RootRef;
    private StorageReference storageReference;
    private StorageReference fetchimages;
    private Uri selectedImageUri;
    private ActivityMainBinding binding;
    private ProgressDialog progressDialog;
    private FirebaseStorage storage;
    private ProgressDialog loadingBar;
    private Toolbar settingsToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        InitilizeFields();


        mAuth=FirebaseAuth.getInstance();
        currentUserID=mAuth.getCurrentUser().getUid();
        RootRef= FirebaseDatabase.getInstance().getReference();

        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        String path="/Users/"+currentUserID+"/Profile Images"+currentUserID+".jpg";
        fetchimages=FirebaseStorage.getInstance().getReference(path);

        UpdateAccountSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UpdateSettings();

            }
        });
        RetriveUserInformation();
        userProfileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openImageChooser();
                uploadButton.setVisibility(View.VISIBLE);
            }
        });

        uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedImageUri != null) {
                    uploadImage(selectedImageUri);
                    uploadButton.setVisibility(View.INVISIBLE);
                } else {
                    Toast.makeText(SettingsActivity.this, "Please select an image first.", Toast.LENGTH_SHORT).show();
                }
            }
        });



    }



    private void InitilizeFields() {

        UpdateAccountSettings=(Button) findViewById(R.id.update_settings);

        username=(EditText) findViewById(R.id.set_user_name);
        userstatus=(EditText) findViewById(R.id.set_profile_status);

        userProfileImage=(CircleImageView) findViewById(R.id.set_profile_image);
        uploadButton = findViewById(R.id.uploadButton);

        storageReference=FirebaseStorage.getInstance().getReference().child("Profile Images");
        loadingBar=new ProgressDialog(this);

        settingsToolbar= (Toolbar) findViewById(R.id.settings_toolbar);
        setSupportActionBar(settingsToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setTitle("Settings");


    }



    private void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedImageUri = data.getData();
            userProfileImage.setImageURI(selectedImageUri);
        }
    }

    private void uploadImage(Uri imageUri) {
        // Generate a unique name for the image
        String imageName = currentUserID + ".jpg";
        final StorageReference imageRef = storageReference.child("Users").child(currentUserID).child("Profile Images").child(imageName);
        loadingBar.setTitle("Set Profile Image");
        loadingBar.setMessage("Please wait,your Profile Pic is being updated...!!");
        loadingBar.setCanceledOnTouchOutside(false);
        loadingBar.show();
        UploadTask uploadTask = imageRef.putFile(imageUri);

        // Handle the upload success or failure
        uploadTask.addOnCompleteListener(SettingsActivity.this, task -> {
            if (task.isSuccessful()) {

                Toast.makeText(SettingsActivity.this, "Image uploaded successfully.", Toast.LENGTH_SHORT).show();
                final String downloaduri="https://firebasestorage.googleapis.com/v0/b/whatsapp-2422c.appspot.com/o/Users%2F"+currentUserID+"%2FProfile%20Images%2F"+currentUserID+".jpg?alt=media&token=4831224a-0e27-43bd-b8e6-280512e867f2";

                Toast.makeText(this, downloaduri, Toast.LENGTH_SHORT).show();

                RootRef.child("Users").child(currentUserID).child("image").setValue(downloaduri).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(SettingsActivity.this, "Image Save Succesfully", Toast.LENGTH_SHORT).show();
                            loadingBar.dismiss();
                        }
                        else
                        {
                            String message=task.getException().toString();
                            Toast.makeText(SettingsActivity.this, "Error : "+message, Toast.LENGTH_SHORT).show();
                            loadingBar.dismiss();
                        }
                    }
                });


            } else {
                Toast.makeText(SettingsActivity.this, "Failed to upload image.", Toast.LENGTH_SHORT).show();
                loadingBar.dismiss();
            }
        });

    }

    private void UpdateSettings() {
        String setUserName=username.getText().toString();
        String setUserStatus=userstatus.getText().toString();

        if(TextUtils.isEmpty(setUserName))
        {
            Toast.makeText(this,"Plese Enter Your Username...",Toast.LENGTH_SHORT).show();
        }

        if(TextUtils.isEmpty(setUserStatus))
        {
            Toast.makeText(this,"Plese Enter Your Status...",Toast.LENGTH_SHORT).show();
        }
        else {

            HashMap<String,Object>profileMap=new HashMap<>();
            profileMap.put("uid",currentUserID);
            profileMap.put("name",setUserName);
            profileMap.put("status",setUserStatus);
            RootRef.child("Users").child(currentUserID).updateChildren(profileMap)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {

                            if (task.isSuccessful())
                            {
                                Toast.makeText(SettingsActivity.this,"Profile Updated Successfully...!",Toast.LENGTH_SHORT).show();
                                SendUserToMainActivity();
                            }
                            else
                            {
                                String error=task.getException().toString();
                                Toast.makeText(SettingsActivity.this,"Some Error Occur...!"+error,Toast.LENGTH_SHORT).show();

                            }
                        }
                    });

        }

    }


    private void SendUserToMainActivity() {
        Intent MainIntent=new Intent(SettingsActivity.this,MainActivity.class);
        MainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(MainIntent);
        finish();
    }

    private void RetriveUserInformation() {
        RootRef.child("Users").child(currentUserID)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if((snapshot.exists()) && (snapshot.hasChild("name") && (snapshot.hasChild("image"))))
                        {
                            String retriveUserName=snapshot.child("name").getValue().toString();
                            String retriveUserStatus=snapshot.child("status").getValue().toString();
                            String retriveProfileImage=snapshot.child("image").getValue().toString();

                            username.setText(retriveUserName);
                            System.out.println(retriveUserName+retriveUserStatus);
                            userstatus.setText(retriveUserStatus);
                            Picasso.get().load(retriveProfileImage).into(userProfileImage);
                            //Picasso.get().load("https://firebasestorage.googleapis.com/v0/b/whatsapp-2422c.appspot.com/o/Users%2FWrBOUcvL6pVI2mnFsbdCDiRih552%2FProfile%20Images%2FWrBOUcvL6pVI2mnFsbdCDiRih552.jpg?alt=media&token=4831224a-0e27-43bd-b8e6-280512e867f2&_gl=1*1b2r9ee*_ga*OTY4NDg0MDc2LjE2OTU3Mjc0OTk.*_ga_CW55HF8NVT*MTY5NjY4MTMyOC4yNi4xLjE2OTY2ODE0MjkuMjUuMC4w").into(userProfileImage);

                        } else if ((snapshot.exists()) && (snapshot.hasChild("name"))) {

                            String retriveUserName=snapshot.child("name").getValue().toString();
                            String retriveUserStatus=snapshot.child("status").getValue().toString();

                            username.setText(retriveUserName);
                            userstatus.setText(retriveUserStatus);

                        }
                        else
                        {

                            Toast.makeText(SettingsActivity.this,"Please Set Your Profile Picture & Update Your Profile Information...!",Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }


}