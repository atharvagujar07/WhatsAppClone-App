package com.example.whatsapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class ChatActivity extends AppCompatActivity {
    private  String messageReciverID,messageReciverName,messageReciverImage,messageSenderID;
    private TextView userName,userLastSeen;
    private CircleImageView userImage;

    private Toolbar ChatToolBar;
    private ImageButton SendMessageButton,SendFilesButton;
    private EditText MessageInputText;
    private FirebaseAuth mAuth;
    private DatabaseReference RootRef;
    private  final List<Messages> messagesList=new ArrayList<>();
    private LinearLayoutManager linearLayoutManager;
    private MessageAdapter messageAdapter;
    private RecyclerView userMessagesList;
    private String saveCurrentTime,saveCurrentDate;
    private String checker="",myUrl="";
    private StorageTask uploadTask;
    private Uri fileUri;
    private ProgressDialog loadingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        messageReciverID=getIntent().getExtras().get("visit_user_id").toString();
        messageReciverName=getIntent().getExtras().get("visit_user_name").toString();
        messageReciverImage=getIntent().getExtras().get("visit_user_image").toString();

        InitilizeConrollers();
        userName.setText(messageReciverName);
        Picasso.get().load(messageReciverImage).placeholder(R.drawable.profilepic).into(userImage);

        SendMessageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               sendMessage();
            }
        });
        DisplayLastSeen();
        SendFilesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                CharSequence options[]=new CharSequence[]
                        {
                                "Images" ,
                                "Pdf Files" ,
                                "Video Files",
                                "Other Files"
                        };
                AlertDialog.Builder builder=new AlertDialog.Builder(ChatActivity.this);
                builder.setTitle("Select File Type");
                builder.setItems(options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (i==0)
                        {
                          checker="image" ;
                            Intent intent=new Intent();
                            intent.setAction(Intent.ACTION_GET_CONTENT);
                            intent.setType("image/*");
                            startActivityForResult(Intent.createChooser(intent,"Select Image"),438);
                        }
                        if (i==1)
                        {
                            checker="pdf";
                            Intent intent=new Intent();
                            intent.setAction(Intent.ACTION_GET_CONTENT);
                            intent.setType("application/pdf");
                            startActivityForResult(Intent.createChooser(intent,"Select PDF"),440);
                        }
                        if (i==2)
                        {
                            checker="video";
                            Intent intent=new Intent();
                            intent.setAction(Intent.ACTION_GET_CONTENT);
                            intent.setType("video/*");
                            startActivityForResult(Intent.createChooser(intent,"Select Video"),439);
                        }
                        if (i==3)
                        {
                            checker="docx";
                            Intent intent=new Intent();
                            intent.setAction(Intent.ACTION_GET_CONTENT);
                            intent.setType("application/*");
                            startActivityForResult(Intent.createChooser(intent,"Select File"),441);
                        }

                    }
                });
                builder.show();
            }
        });

    }
    private void DisplayLastSeen()
    {
        RootRef.child("Users").child(messageReciverID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.child("userState").hasChild("state"))
                {
                    String state= snapshot.child("userState").child("state").getValue().toString();
                    String date= snapshot.child("userState").child("date").getValue().toString();
                    String time= snapshot.child("userState").child("time").getValue().toString();
                    if(state.equals("online"))
                    {
                        userLastSeen.setText("online");
                    }
                    else if (state.equals("offline"))
                    {
                        userLastSeen.setText("offline \nLast Seen:"+date+" "+time);
                    }
                }
                else
                {
                    userLastSeen.setText("offline");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void InitilizeConrollers() {

        ChatToolBar=(Toolbar) findViewById(R.id.chat_toolbar);
        setSupportActionBar(ChatToolBar);

        ActionBar actionBar=getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowCustomEnabled(true);

        LayoutInflater layoutInflater=(LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View actionBarView=layoutInflater.inflate(R.layout.custom_chat_bar,null);
        actionBar.setCustomView(actionBarView);

        userImage=(CircleImageView) findViewById(R.id.custom_profile_image);
        userName=(TextView) findViewById(R.id.custom_profile_name);
        userLastSeen=(TextView) findViewById(R.id.custom_user_last_seen);

        SendFilesButton=(ImageButton) findViewById(R.id.send_files_button);
        SendMessageButton=(ImageButton) findViewById(R.id.send_massge_button);
        MessageInputText=(EditText) findViewById(R.id.input_message);
        mAuth=FirebaseAuth.getInstance();
        messageSenderID=mAuth.getCurrentUser().getUid();
        RootRef= FirebaseDatabase.getInstance().getReference();

        messageAdapter =new MessageAdapter(messagesList);
        userMessagesList=(RecyclerView)findViewById(R.id.private_messages_list_of_users);
        linearLayoutManager=new LinearLayoutManager(this);
        userMessagesList.setLayoutManager(linearLayoutManager);
        userMessagesList.setAdapter(messageAdapter);

        Calendar calendar=Calendar.getInstance();
        SimpleDateFormat currentDate=new SimpleDateFormat("MMM dd,yyyy");
        saveCurrentDate=currentDate.format(calendar.getTime());
        SimpleDateFormat currentTime=new SimpleDateFormat("hh:mm a");
        saveCurrentTime=currentTime.format(calendar.getTime());
        loadingBar=new ProgressDialog(this);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==438 && resultCode==RESULT_OK && data!=null && data.getData()!=null)
        {

            loadingBar.setTitle("Sending file");
            loadingBar.setMessage("Please wait,we are sending your file...!!");
            loadingBar.setCanceledOnTouchOutside(false);
            loadingBar.show();
            fileUri =data.getData();
            if(!checker.equals("image"))
            {

            } else if (checker.equals("image"))
            {
                final String messageSenderRef="Messages/"+messageSenderID +"/"+messageReciverID;
                final String messageReceiverRef="Messages/"+messageReciverID +"/"+messageSenderID;
                DatabaseReference userMessageKeyRef=RootRef.child("Messages")
                        .child(messageSenderID).child(messageReciverID).push();
                final  String messagePushID=userMessageKeyRef.getKey();

                StorageReference storageReference= FirebaseStorage.getInstance().getReference().child("Image Files");
                StorageReference filePath=storageReference.child(messagePushID+"."+"jpg");
                uploadTask=filePath.putFile(fileUri);
                uploadTask.continueWithTask(new Continuation() {
                    @Override
                    public Object then(@NonNull Task task) throws Exception {
                        if(!task.isSuccessful())
                        {
                            throw  task.getException();
                        }
                        return filePath.getDownloadUrl();
                    }
                }).addOnCompleteListener(new OnCompleteListener<Uri>()  {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task) {
                        if(task.isSuccessful())
                        {
                            Uri downloadUri=task.getResult();
                            myUrl=downloadUri.toString();
                            Map messageImageBody= new HashMap();
                            messageImageBody.put("message",myUrl);
                            messageImageBody.put("name",fileUri.getLastPathSegment());
                            messageImageBody.put("type",checker);
                            messageImageBody.put("from",messageSenderID);
                            messageImageBody.put("to",messageReciverID);
                            messageImageBody.put("messageID",messagePushID);
                            messageImageBody.put("time",saveCurrentTime);
                            messageImageBody.put("date",saveCurrentDate);

                            Map messageBodyDetails=new HashMap();
                            messageBodyDetails.put(messageSenderRef+"/"+messagePushID,messageImageBody);
                            messageBodyDetails.put(messageReceiverRef+"/"+messagePushID,messageImageBody);

                            RootRef.updateChildren(messageBodyDetails).addOnCompleteListener(new OnCompleteListener() {
                                @Override
                                public void onComplete(@NonNull Task task) {
                                    if(task.isSuccessful())
                                    {
                                        loadingBar.dismiss();
                                        Toast.makeText(ChatActivity.this, "Message Sent Successfully", Toast.LENGTH_SHORT).show();
                                    }
                                    else
                                    {
                                        loadingBar.dismiss();
                                        Toast.makeText(ChatActivity.this, "Faild to Sent Message", Toast.LENGTH_SHORT).show();
                                    }
                                    MessageInputText.setText("");
                                }
                            });
                        }

                    }
                });
            }
            else
            {
                Toast.makeText(this, "Nothing Selected Error.", Toast.LENGTH_SHORT).show();
            }
        }

        if(requestCode==439 && resultCode==RESULT_OK && data!=null && data.getData()!=null)
        {

            loadingBar.setTitle("Sending file");
            loadingBar.setMessage("Please wait,we are sending your file...!!");
            loadingBar.setCanceledOnTouchOutside(false);
            loadingBar.show();
            fileUri =data.getData();
            if(!checker.equals("video"))
            {

            } else if (checker.equals("video"))
            {
                final String messageSenderRef="Messages/"+messageSenderID +"/"+messageReciverID;
                final String messageReceiverRef="Messages/"+messageReciverID +"/"+messageSenderID;
                DatabaseReference userMessageKeyRef=RootRef.child("Messages")
                        .child(messageSenderID).child(messageReciverID).push();
                final  String messagePushID=userMessageKeyRef.getKey();

                StorageReference storageReference= FirebaseStorage.getInstance().getReference().child("Video Files");
                StorageReference filePath=storageReference.child(messagePushID+"."+"mp4");
                uploadTask=filePath.putFile(fileUri);
                uploadTask.continueWithTask(new Continuation() {
                    @Override
                    public Object then(@NonNull Task task) throws Exception {
                        if(!task.isSuccessful())
                        {
                            throw  task.getException();
                        }
                        return filePath.getDownloadUrl();
                    }
                }).addOnCompleteListener(new OnCompleteListener<Uri>()  {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task) {
                        if(task.isSuccessful())
                        {
                            Uri downloadUri=task.getResult();
                            myUrl=downloadUri.toString();
                            Map messagevideoBody= new HashMap();
                            messagevideoBody.put("message",myUrl);
                            messagevideoBody.put("name",fileUri.getLastPathSegment());
                            messagevideoBody.put("type",checker);
                            messagevideoBody.put("from",messageSenderID);
                            messagevideoBody.put("to",messageReciverID);
                            messagevideoBody.put("messageID",messagePushID);
                            messagevideoBody.put("time",saveCurrentTime);
                            messagevideoBody.put("date",saveCurrentDate);

                            Map messageBodyDetails=new HashMap();
                            messageBodyDetails.put(messageSenderRef+"/"+messagePushID,messagevideoBody);
                            messageBodyDetails.put(messageReceiverRef+"/"+messagePushID,messagevideoBody);

                            RootRef.updateChildren(messageBodyDetails).addOnCompleteListener(new OnCompleteListener() {
                                @Override
                                public void onComplete(@NonNull Task task) {
                                    if(task.isSuccessful())
                                    {
                                        loadingBar.dismiss();
                                        Toast.makeText(ChatActivity.this, "Message Sent Successfully", Toast.LENGTH_SHORT).show();
                                    }
                                    else
                                    {
                                        loadingBar.dismiss();
                                        Toast.makeText(ChatActivity.this, "Faild to Sent Message", Toast.LENGTH_SHORT).show();
                                    }
                                    MessageInputText.setText("");
                                }
                            });
                        }

                    }
                });
            }
            else
            {
                Toast.makeText(this, "Nothing Selected Error.", Toast.LENGTH_SHORT).show();
            }
        }

        if(requestCode==440 && resultCode==RESULT_OK && data!=null && data.getData()!=null)
        {

            loadingBar.setTitle("Sending file");
            loadingBar.setMessage("Please wait,we are sending your file...!!");
            loadingBar.setCanceledOnTouchOutside(false);
            loadingBar.show();
            fileUri =data.getData();
            if(!checker.equals("pdf"))
            {

            } else if (checker.equals("pdf"))
            {
                final String messageSenderRef="Messages/"+messageSenderID +"/"+messageReciverID;
                final String messageReceiverRef="Messages/"+messageReciverID +"/"+messageSenderID;
                DatabaseReference userMessageKeyRef=RootRef.child("Messages")
                        .child(messageSenderID).child(messageReciverID).push();
                final  String messagePushID=userMessageKeyRef.getKey();

                StorageReference storageReference= FirebaseStorage.getInstance().getReference().child("PDF Files");
                StorageReference filePath=storageReference.child(messagePushID+"."+"pdf");
                uploadTask=filePath.putFile(fileUri);
                uploadTask.continueWithTask(new Continuation() {
                    @Override
                    public Object then(@NonNull Task task) throws Exception {
                        if(!task.isSuccessful())
                        {
                            throw  task.getException();
                        }
                        return filePath.getDownloadUrl();
                    }
                }).addOnCompleteListener(new OnCompleteListener<Uri>()  {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task) {
                        if(task.isSuccessful())
                        {
                            Uri downloadUri=task.getResult();
                            myUrl=downloadUri.toString();
                            Map messagepdfBody= new HashMap();
                            messagepdfBody.put("message",myUrl);
                            messagepdfBody.put("name",fileUri.getLastPathSegment());
                            messagepdfBody.put("type",checker);
                            messagepdfBody.put("from",messageSenderID);
                            messagepdfBody.put("to",messageReciverID);
                            messagepdfBody.put("messageID",messagePushID);
                            messagepdfBody.put("time",saveCurrentTime);
                            messagepdfBody.put("date",saveCurrentDate);

                            Map messageBodyDetails=new HashMap();
                            messageBodyDetails.put(messageSenderRef+"/"+messagePushID,messagepdfBody);
                            messageBodyDetails.put(messageReceiverRef+"/"+messagePushID,messagepdfBody);

                            RootRef.updateChildren(messageBodyDetails).addOnCompleteListener(new OnCompleteListener() {
                                @Override
                                public void onComplete(@NonNull Task task) {
                                    if(task.isSuccessful())
                                    {
                                        loadingBar.dismiss();
                                        Toast.makeText(ChatActivity.this, "Message Sent Successfully", Toast.LENGTH_SHORT).show();
                                    }
                                    else
                                    {
                                        loadingBar.dismiss();
                                        Toast.makeText(ChatActivity.this, "Faild to Sent Message", Toast.LENGTH_SHORT).show();
                                    }
                                    MessageInputText.setText("");
                                }
                            });
                        }

                    }
                });
            }
            else
            {
                Toast.makeText(this, "Nothing Selected Error.", Toast.LENGTH_SHORT).show();
            }
        }

        if(requestCode==441 && resultCode==RESULT_OK && data!=null && data.getData()!=null)
        {

            loadingBar.setTitle("Sending file");
            loadingBar.setMessage("Please wait,we are sending your file...!!");
            loadingBar.setCanceledOnTouchOutside(false);
            loadingBar.show();
            fileUri =data.getData();
            if(!checker.equals("docx"))
            {

            } else if (checker.equals("docx"))
            {
                final String messageSenderRef="Messages/"+messageSenderID +"/"+messageReciverID;
                final String messageReceiverRef="Messages/"+messageReciverID +"/"+messageSenderID;
                DatabaseReference userMessageKeyRef=RootRef.child("Messages")
                        .child(messageSenderID).child(messageReciverID).push();
                final  String messagePushID=userMessageKeyRef.getKey();

                StorageReference storageReference= FirebaseStorage.getInstance().getReference().child("MS Document Files");
                StorageReference filePath=storageReference.child(messagePushID);
                uploadTask=filePath.putFile(fileUri);
                uploadTask.continueWithTask(new Continuation() {
                    @Override
                    public Object then(@NonNull Task task) throws Exception {
                        if(!task.isSuccessful())
                        {
                            throw  task.getException();
                        }
                        return filePath.getDownloadUrl();
                    }
                }).addOnCompleteListener(new OnCompleteListener<Uri>()  {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task) {
                        if(task.isSuccessful())
                        {
                            Uri downloadUri=task.getResult();
                            myUrl=downloadUri.toString();
                            Map messagedocxBody= new HashMap();
                            messagedocxBody.put("message",myUrl.toString());
                            messagedocxBody.put("name",fileUri.getLastPathSegment());
                            messagedocxBody.put("type",checker);
                            messagedocxBody.put("from",messageSenderID);
                            messagedocxBody.put("to",messageReciverID);
                            messagedocxBody.put("messageID",messagePushID);
                            messagedocxBody.put("time",saveCurrentTime);
                            messagedocxBody.put("date",saveCurrentDate);

                            Map messageBodyDetails=new HashMap();
                            messageBodyDetails.put(messageSenderRef+"/"+messagePushID,messagedocxBody);
                            messageBodyDetails.put(messageReceiverRef+"/"+messagePushID,messagedocxBody);

                            RootRef.updateChildren(messageBodyDetails).addOnCompleteListener(new OnCompleteListener() {
                                @Override
                                public void onComplete(@NonNull Task task) {
                                    if(task.isSuccessful())
                                    {
                                        loadingBar.dismiss();
                                        Toast.makeText(ChatActivity.this, "Message Sent Successfully", Toast.LENGTH_SHORT).show();
                                    }
                                    else
                                    {
                                        loadingBar.dismiss();
                                        Toast.makeText(ChatActivity.this, "Faild to Sent Message", Toast.LENGTH_SHORT).show();
                                    }
                                    MessageInputText.setText("");
                                }
                            });
                        }

                    }
                });
            }
            else
            {
                Toast.makeText(this, "Nothing Selected Error.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        RootRef.child("Messages").child(messageSenderID).child(messageReciverID)
                .addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                       Messages messages=snapshot.getValue(Messages.class);
                       messagesList.add(messages);
                       messageAdapter.notifyDataSetChanged();
                       userMessagesList.smoothScrollToPosition(userMessagesList.getAdapter().getItemCount());
                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    private void sendMessage()
    {
        String messageText=MessageInputText.getText().toString();
        if(TextUtils.isEmpty(messageText))
        {
            Toast.makeText(this, "write a message First", Toast.LENGTH_SHORT).show();
        }else
        {
            String messageSenderRef="Messages/"+messageSenderID +"/"+messageReciverID;
            String messageReceiverRef="Messages/"+messageReciverID +"/"+messageSenderID;
            DatabaseReference userMessageKeyRef=RootRef.child("Messages")
                    .child(messageSenderID).child(messageReciverID).push();

            String messagePushID=userMessageKeyRef.getKey();
            Map messageTextBody= new HashMap();
            messageTextBody.put("message",messageText);
            messageTextBody.put("type","text");
            messageTextBody.put("from",messageSenderID);
            messageTextBody.put("to",messageReciverID);
            messageTextBody.put("messageID",messagePushID);
            messageTextBody.put("time",saveCurrentTime);
            messageTextBody.put("date",saveCurrentDate);

            Map messageBodyDetails=new HashMap();
            messageBodyDetails.put(messageSenderRef+"/"+messagePushID,messageTextBody);
            messageBodyDetails.put(messageReceiverRef+"/"+messagePushID,messageTextBody);

            RootRef.updateChildren(messageBodyDetails).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {
                   if(task.isSuccessful())
                   {
                       Toast.makeText(ChatActivity.this, "Message Sent Successfully", Toast.LENGTH_SHORT).show();
                   }
                   else
                   {
                       Toast.makeText(ChatActivity.this, "Faild to Sent Message", Toast.LENGTH_SHORT).show();
                   }
                   MessageInputText.setText("");
                }
            });
        }
    }
}