package com.example.whatsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import androidx.annotation.NonNull;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class entermobilenumberone extends AppCompatActivity {

    private EditText entermobailnumber;
    private Button getotpButton;
    private FirebaseAuth mAuth;
    private String verificationcode;
    private PhoneAuthProvider.ForceResendingToken resendingToken;
    private long timeseconds=60;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entermobilenumberone);
        entermobailnumber = (EditText) findViewById(R.id.input_mobile_number);
        getotpButton = (Button) findViewById(R.id.buttongetotp);

        mAuth=FirebaseAuth.getInstance();
        ProgressBar progressBar = (ProgressBar) findViewById(R.id.progressbar_sending_otp);

        getotpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!entermobailnumber.getText().toString().trim().isEmpty()) {
                    if (entermobailnumber.getText().toString().trim().length() == 10) {
                        progressBar.setVisibility(View.VISIBLE);
                        getotpButton.setVisibility(View.INVISIBLE);
                        PhoneAuthOptions.Builder builder=
                                PhoneAuthOptions.newBuilder(mAuth).
                                        setPhoneNumber("+91"+entermobailnumber.getText().toString())
                                        .setTimeout(timeseconds, TimeUnit.SECONDS)
                                        .setActivity(entermobilenumberone.this)
                                        .setCallbacks(       new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                                            @Override
                                            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                                                signIn(phoneAuthCredential);
                                            }

                                            @Override
                                            public void onVerificationFailed(@NonNull FirebaseException e) {
                                                progressBar.setVisibility(View.GONE);
                                                getotpButton.setVisibility(View.VISIBLE);
                                                Toast.makeText(entermobilenumberone.this, "Error Please Check Your Phone Number", Toast.LENGTH_SHORT).show();
                                            }

                                            @Override
                                            public void onCodeSent(@NonNull String backendotp, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                                progressBar.setVisibility(View.GONE);
                                                getotpButton.setVisibility(View.VISIBLE);
                                                resendingToken=forceResendingToken;
                                                verificationcode=backendotp;
                                                Toast.makeText(entermobilenumberone.this, "Otp Send Succesfully...!!"+verificationcode.toString(), Toast.LENGTH_SHORT).show();

                                                Intent intent = new Intent(getApplicationContext(), verifyenterotptwo.class);
                                                intent.putExtra("mobile", entermobailnumber.getText().toString());
                                                intent.putExtra("backendotp",backendotp);
                                                startActivity(intent);

                                            }
                                        });
                        PhoneAuthProvider.verifyPhoneNumber(builder.build());

                    } else {
                        Toast.makeText(entermobilenumberone.this, "Please enter correct phone number...", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(entermobilenumberone.this, "Please enter phone number...", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void signIn(PhoneAuthCredential phoneAuthCredential) {
    }
}